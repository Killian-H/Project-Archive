/*
 * TCSS 342
 * 
 * This class is designed to test out the use of different structures.
 */
package programs;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

/**
 * This class is intended to read a text file and demonstrate the difference in
 * run time between the use of a HashMap and a TreeMap.
 * 
 * @author Killian Hickey
 * @version 02/17/2021
 *
 */
public final class WordCount {

    /** Default number of tests to run. */
    private static final int NUM_OF_TESTS = 10;

    /**
     * Private constructor so instances of this class can not be made.
     */
    private WordCount() {
        // Do Nothing
    }

    /**
     * Driver of the program.
     * 
     * @param theArgs Standard parameter of the main method.
     */
    public static void main(final String[] theArgs) {
        final Scanner console = new Scanner(System.in);
        final String nameOfFile = promptForFileName(console);
        final File userFile = checkFile(console, nameOfFile);
        final List<String> fullText = new ArrayList<String>();
        final Map<String, ValueIncrement> treeStorage = new TreeMap<>();
        List<Map.Entry<String, ValueIncrement>> topNListTree = new ArrayList<>();
        List<Map.Entry<String, ValueIncrement>> topNListHash = new ArrayList<>();
        final Map<String, ValueIncrement> hashStorage = new HashMap<>();
        final Deque<Long> timeHolder = new ArrayDeque<>();
        getFullText(fullText, userFile);
        System.out.println(fullText.toString());
        final int topNWords = promptForTopN(console, 
                (int) fullText.stream().distinct().count());
        topNListTree = mapTest(treeStorage, fullText, timeHolder, topNWords, 
                userFile.getName());
        printTopNWords(topNListTree, fullText.size());
        topNListHash = mapTest(hashStorage, fullText, timeHolder, topNWords, 
                userFile.getName());
        printTopNWords(topNListHash, fullText.size());
        
    }

    private static void printTopNWords(final List<Entry<String, ValueIncrement>> 
        theTopNList, final int theSize) {
        System.out.println("The number of words in the file is: " + theSize);
        System.out.println("The top " + theTopNList.size() + " words are:");
        for (int i = 0; i < theTopNList.size(); i++) {
            System.out.println("#" + (i + 1) + ". " + theTopNList.get(i).getKey() + " " 
                    + theTopNList.get(i).getValue());
        }

    }

    /**
     * This method iterates through an ArrayList holding the words within the
     * text document. Unique words are put into the map as a key, repeated words
     * increment the value associated with the given key. The top N words are
     * then place in a list using an entry set of the Map. This process is repeated
     * 10 times, and the runtime is saved for each run.
     * 
     * @param theMapStorage The map being used.
     * @param theFullText The text file being read.
     * @param theTimeHolder The stack holding the run times.
     * @param theTopN The top N words the user wishes to see.
     * @param theFileName The name of the file.
     * @return Returns a list of the top N Strings.
     */
    private static ArrayList<Entry<String, ValueIncrement>> mapTest(
            final Map<String, ValueIncrement> theMapStorage, 
            final List<String> theFullText,
            final Deque<Long> theTimeHolder, final int theTopN, 
            final String theFileName) {
        ValueIncrement index;
        long start;
        long finish;
        final List<Map.Entry<String, ValueIncrement>> sortedList = 
                new ArrayList<>(theMapStorage.entrySet());
        final ArrayList<Map.Entry<String, ValueIncrement>> topNList = 
                new ArrayList<>(theMapStorage.entrySet());
        for (int i = 0; i <= NUM_OF_TESTS; i++) {
            start = System.currentTimeMillis();
            for (int j = 0; j < theFullText.size(); j++) {
                index = theMapStorage.get(theFullText.get(j));
                if (index != null) {
                    index.incrementCounter();
                } else {
                    theMapStorage.put(theFullText.get(j), new ValueIncrement());
                }
            }
            for (Map.Entry<String, ValueIncrement> current : theMapStorage.entrySet()) {
                sortedList.add(current);
            }
            finish = System.currentTimeMillis();
            sortedList.sort(Entry.comparingByValue());
            for (int k = 0; k < theTopN; k++) {
                topNList.add(sortedList.get(k));
            }
            theTimeHolder.push(finish - start);
            if (i < NUM_OF_TESTS) {
                theMapStorage.clear();
                theMapStorage.entrySet().clear();
                sortedList.clear();
                topNList.clear();
            }
        }
        reportMapInfo(theMapStorage, theTopN, theTimeHolder, theFileName);
        return topNList;
    }

    /**
     * Reports info about which type of map was used as well as the best runtime
     * for the map after 10 runs.
     * 
     * @param theMapStorage The map being used.
     * @param theTopN The top N words the user wishes to see.
     * @param theTimeHolder The stack holding the top 10 times.
     * @param theFileName The name of the file being read.
     */
    private static void reportMapInfo(final Map<String, ValueIncrement> theMapStorage, 
            final int theTopN, final Deque<Long> 
        theTimeHolder, final String theFileName) {
        final String className = theMapStorage.getClass().getSimpleName();
        long best = theTimeHolder.pop();
        long check = 0;
        while (!theTimeHolder.isEmpty()) {
            check = theTimeHolder.pop();
            if (check < best) {
                best = check;
            }
        }
        System.out.print("\nUsing " + theFileName + " and using " + className);
        System.out.println("\nThe best runtime for 10 runs was: " + best + " ms.\n");

    }

    /**
     * Prompts for the name of the file the user would like to read.
     * 
     * @param theConsole Scanner to read input from user.
     * @return Returns the name of the file the user enters.
     */
    private static String promptForFileName(final Scanner theConsole) {
        final String askForName = "Enter the name of the file " 
                + "you would like to read: ";
        System.out.print(askForName);
        final String nameOfFile = theConsole.next();
        return nameOfFile;
    }

    /**
     * Checks to see if the file name entered by the user exists. If it does not
     * exist they will be prompted to try again.
     * 
     * @param theConsole    Scanner to read input from user.
     * @param theNameOfFile The name of the file the user wants to read.
     * @return Returns the existing File.
     */
    private static File checkFile(final Scanner theConsole, final String theNameOfFile) {
        File f = new File(theNameOfFile);
        while (!f.canRead()) {
            System.out.println("\nSorry, the file could not be found. Make sure the file "
                    + "you want to read is in the correct directory, and spelled " 
                    + "correctly.");
            f = new File(promptForFileName(theConsole));
        }
        return f;
    }

    /**
     * Prompts the user to enter an integer. This integer will be used to show the
     * user the top N words by order of how frequently they appear in the text. Will
     * re-prompt the user if they do not enter a valid integer.
     * 
     * @param theConsole Scanner to read input from user.
     * @param theMaxSize The total number of words in the document.
     * @return Returns the number the user selects.
     */
    private static int promptForTopN(final Scanner theConsole, final int theMaxSize) {
        final String askForTopN = "Enter the number for the top N most frequent words: ";
        final String errorMsg = "Your input was not an integer, please try again.\n";
        final String tooLarge = "Your requested top N words is not a valid integer."
                + " Please enter a number between 1 and " + theMaxSize + ".\n";
        System.out.print("\n" + askForTopN);
        while (!theConsole.hasNextInt()) {
            theConsole.next();
            System.out.print(errorMsg);
            System.out.print(askForTopN);
        }
        int topN = theConsole.nextInt();
        if (topN > theMaxSize || topN < 1) {
            System.out.print(tooLarge);
            topN = promptForTopN(theConsole, theMaxSize);
        }

        return topN;
    }

    /**
     * Adds the entirety of the text the user wishes to read into a list.
     * 
     * @param theFullText The list which holds all the text.
     * @param theUserFile The file being read.
     */
    private static void getFullText(final List<String> theFullText, 
            final File theUserFile) {
        try {
            final Scanner readFile = new Scanner(theUserFile);
            String current = "";
            while (readFile.hasNext()) {
                current = readFile.next();
                current = current.replaceAll("[^0-9A-Za-z']", "");
                current = current.replaceAll("\\s+", "");
                current = current.trim();
                if (!"".equals(current)) {
                    theFullText.add(current.toLowerCase());
                }
            }
            readFile.close();
        } catch (final FileNotFoundException e) {
            e.printStackTrace();
        }

    }

}
