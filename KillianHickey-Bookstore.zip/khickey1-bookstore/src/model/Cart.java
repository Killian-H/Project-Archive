
/*
 * TCSS 305
 * 
 * Creates the cart object which holds all the info about the customers
 * order, including the price.
 */

package model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;

/**
 * Represents an online shopping cart for a bookstore.
 * 
 * @author Killian Hickey
 * @version October 16, 2020
 */
public class Cart {

	/** Check for if the customer is a member. */
	private boolean isMember;

	/** Map containing information about the order. */
	private Map<Item, Integer> cart;

	/**
	 * Constructor which initializes a HashMap and boolean value for use in
	 * computing the total for the order.
	 */
	public Cart() {
		cart = new HashMap<Item, Integer>();
		isMember = false;
	}

	/**
	 * Adds the item being purchased as well as the quantity of said item to a
	 * HashMap.
	 * 
	 * @param theOrder The object containing the item being purchased, and the
	 *                 quantity of the item.
	 * @throws IllegalArgumentException If theOrder is empty, or if the quantity of
	 *                                  the order is negative.
	 */
	public void add(final ItemOrder theOrder) {
		cart.put(Objects.requireNonNull(theOrder.getItem()), theOrder.getQuantity());
	}

	/**
	 * Sets the customers membership status.
	 * 
	 * @param theMembership The membership status of the customer.
	 */
	public void setMembership(final boolean theMembership) {
		isMember = theMembership;
	}

	/**
	 * Calculates the total cost of the customers order. If the customer is a member
	 * and the item has a bulk quantity bulk pricing will be applied to the order.
	 * 
	 * @return The total cost of the customers order.
	 */
	public BigDecimal calculateTotal() {
		BigDecimal totalCost = BigDecimal.ZERO;
		Iterator<Item> itr = cart.keySet().iterator();
		while (itr.hasNext()) {
			Item element = itr.next();
			if (isMember && element.isBulk() && cart.get(element) >= element.getBulkQuantity()) {
				int numOfBulk = cart.get(element) / element.getBulkQuantity();
				int numNotBulk = cart.get(element) % element.getBulkQuantity();
				BigDecimal bulkPricing = element.getBulkPrice().multiply(new BigDecimal(numOfBulk));
				BigDecimal normPricing = element.getPrice().multiply(new BigDecimal(numNotBulk));
				BigDecimal priceOfBulk = bulkPricing.add(normPricing);
				totalCost = totalCost.add(priceOfBulk);
			} else {
				BigDecimal price = element.getPrice().multiply(new BigDecimal(cart.get(element)));
				totalCost = totalCost.add(price);
			}
		}

		return totalCost;
	}

	/**
	 * Empties the cart.
	 */
	public void clear() {
		cart.clear();
	}

	/**
	 * How many items are in the cart?
	 * 
	 * @return The number of items in the cart.
	 */
	public int getCartSize() {
		int cartSize = 0;
		Iterator<Item> itr = cart.keySet().iterator();
		while (itr.hasNext()) {
			cartSize += cart.get(itr.next());
		}
		return cartSize;
	}

	/**
	 * Returns a string which details the item being purchased, as well as the
	 * quantity of the item being purchased.
	 */
	@Override
	public String toString() {
		String cartRep = "";
		Iterator<Item> itr = cart.keySet().iterator();
		while (itr.hasNext()) {
			Item element = itr.next();
			cartRep += "Item: " + element + "Quantity: " + cart.get(element) + "\n";
		}
		return cartRep;

	}
}
