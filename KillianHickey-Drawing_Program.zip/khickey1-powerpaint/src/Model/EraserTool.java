package Model;

import java.awt.Point;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.geom.Path2D;

public class EraserTool extends AbstractPaintTool {

	private static final int MY_MNEMONIC = KeyEvent.VK_A;

	private static final String MY_NAME = "Eraser";

	private Point myNextPoint;
	
	private Path2D.Double myEraser;

	public EraserTool() {
		super(MY_NAME, MY_MNEMONIC);
		myNextPoint = DEFAULT_POINT;
		myEraser = new Path2D.Double();
	}

	@Override
	public Shape getShape() {
		return myEraser;
	}

	@Override
	public void setStartPoint(final Point thePoint) {
		super.setStartPoint(thePoint);
		myNextPoint = thePoint;
		myEraser.moveTo(thePoint.x, thePoint.y);
	}

	@Override
	public void setNextPoint(Point thePoint) {
		myEraser.lineTo(thePoint.x, thePoint.y);
	}

	@Override
	public void reset() {
		super.reset();
		myEraser = new Path2D.Double();
	}
}
