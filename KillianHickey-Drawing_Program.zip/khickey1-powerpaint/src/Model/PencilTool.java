/**
 * TCSS 305
 * 
 * Creates the Pencil Tool object which provides specified behavior for this specific tool.
 */
package Model;

import java.awt.Point;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.geom.Path2D;

/**
 * This class extends Abstract Paint Tool to give detailed information about
 * what shape the pencil tool should return, as well as its name, and mnemonic.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class PencilTool extends AbstractPaintTool {

	/** The name of the tool. */
	private static final String MY_NAME = "Pencil";

	/** The mnemonic associated with the tool. */
	private static final int MY_MNEMONIC = KeyEvent.VK_P;

	/** The next point after the start point. */
	private Point myNextPoint;
	
	/** The path object for this shape. */
	private Path2D.Double myPencil;

	/**
	 * A constructor which assigns the name and the mnemonic for the tool. It also
	 * provides a default starting point for the next point.
	 */
	public PencilTool() {
		super(MY_NAME, MY_MNEMONIC);
		myNextPoint = DEFAULT_POINT;
		myPencil = new Path2D.Double();
	}

	/**
	 * Returns the shape for this tool. In this case it is a path which will
	 * draw along the path the user drags their mouse.
	 * 
	 * @return Returns a Path.
	 */
	@Override
	public Shape getShape() {
		return myPencil;
	}

	/**
	 * Sets the start point for the pencil's path. Assigns the next point to this
	 * point as well.
	 * 
	 * @param thePoint The point which the user clicks in the drawing panel.
	 */
	@Override
	public void setStartPoint(final Point thePoint) {
		super.setStartPoint(thePoint);
		myNextPoint = thePoint;
		myPencil.moveTo(thePoint.x, thePoint.y);
	}

	/**
	 * Sets the next point the path will go to.
	 * 
	 * @param thePoint The point which the user drags to.
	 */
	@Override
	public void setNextPoint(Point thePoint) {
		myPencil.lineTo(thePoint.x, thePoint.y);
	}

	/**
	 * Stops the curent path, and creates a new path for the pencil object.
	 */
	@Override
	public void reset() {
		super.reset();
		myPencil = new Path2D.Double();
	}

}
