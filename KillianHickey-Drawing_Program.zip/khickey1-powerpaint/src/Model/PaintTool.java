/**
 * TCSS 305
 * 
 * Creates the interface all tools will inherit from.
 */
package Model;

import java.awt.Point;
import java.awt.Shape;

/**
 * This class provides a template for the behavior each tool should have.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public interface PaintTool {

	/**
	 * The name of the tool.
	 * 
	 * @return The name of the tool.
	 */
	String getName();

	/**
	 * The mnemonic associated with this tool.
	 * 
	 * @return The mnemonic for this tool.
	 */
	int getMnemonic();

	/**
	 * The shape associated with this tool.
	 * 
	 * @return The shape for this tool.
	 */
	Shape getShape();

	/**
	 * Sets the start point of the shape.
	 * 
	 * @param thePoint The point where the user clicks on the panel.
	 */
	void setStartPoint(Point thePoint);

	/**
	 * The start point for this shape.
	 * 
	 * @return The start point.
	 */
	Point getStartPoint();

	/**
	 * Sets the next point the user drags their mouse to, and where they release the
	 * mouse at.
	 * 
	 * @param thePoint The location of the mouse.
	 */
	void setNextPoint(Point thePoint);

	void reset();
}
