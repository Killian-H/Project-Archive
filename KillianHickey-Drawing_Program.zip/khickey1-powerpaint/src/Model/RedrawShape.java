/*
 * TCSS 305
 * 
 * provides the ability to save the shape the user creates in the drawing panel.
 */

package Model;

import java.awt.Color;
import java.awt.Shape;
import java.util.Objects;

/**
 * The purpose of this class is to work in tandem with the drawing panel. It
 * provides the ability to save the shape the user creates, as well as the color
 * and line width of said shape.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 */
public class RedrawShape {

	/** One of the shapes that are possible to draw. */
	private final Shape myShape;

	/** The color of the shape. */
	private final Color myColor;

	/** The line width of the shape. */
	private final int myLineWidth;

	/**
	 * Initializes the shape to what the user draws in the drawing panel.
	 * 
	 * @param theShape     The shape the user draws.
	 * @param theColor     The color of the shape.
	 * @param theLineWidth The line width of the shape.
	 */
	public RedrawShape(Shape theShape, Color theColor, int theLineWidth) {
		myShape = Objects.requireNonNull(theShape);
		myColor = Objects.requireNonNull(theColor);
		if (theLineWidth < 0) {
			throw new IllegalArgumentException("Line width must be greater than or equal to 0.");
		}
		myLineWidth = theLineWidth;
	}

	/**
	 * Gets the shape the user draws.
	 * 
	 * @return The shape.
	 */
	public Shape getShape() {
		return myShape;
	}

	/**
	 * Gets the color of the shape.
	 * 
	 * @return The color.
	 */
	public Color getColor() {
		return myColor;
	}

	/**
	 * Gets the line width of the shape.
	 * 
	 * @return The line width.
	 */
	public int getWidth() {
		return myLineWidth;
	}

}
