/*
 * TCSS 305
 * 
 * Provides the basic behavior for the tools needed in the drawing panel.
 */
package Model;

import java.awt.Point;
import java.awt.Shape;

/**
 * This class provides the general behavior needed for the tools being
 * implemented into the power paint drawing panel. Specified behavior will be
 * handled by the tool itself.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public abstract class AbstractPaintTool implements PaintTool {

	/** The default starting point. */
	public static final Point DEFAULT_POINT = new Point(-10, -10);

	/** The name of the tool. */
	private final String myToolName;

	/** the Mnemonic associated with the tool. */
	private final int myMnemonic;

	/** The starting point of the drawing. */
	private Point myStartPoint;

	/**
	 * Constructor which initializes the tool name, its mnemonic, and the default
	 * starting point. The default starting point is outside of the viewable window.
	 * 
	 * @param theToolName The name of the tool.
	 * @param theMnemonic The mnemonic associated with the tool.
	 */
	public AbstractPaintTool(final String theToolName, final int theMnemonic) {
		if (theToolName == null) {
			throw new NullPointerException("Name of tool should not be null.");
		}
		if (theToolName.isEmpty()) {
			throw new IllegalArgumentException("Tool must have a name.");
		}
		if (theMnemonic < 0) {
			throw new IllegalArgumentException("Mnemonic should be greater than or equal to 0.");
		}
		myToolName = theToolName;
		myMnemonic = theMnemonic;
		myStartPoint = DEFAULT_POINT;
	}

	/**
	 * Returns the name of the tool.
	 * 
	 * @return The tool name.
	 */
	@Override
	public String getName() {
		return myToolName;
	}

	/**
	 * Returns the mnemonic associated with the tool.
	 * 
	 * @return the Mnemonic.
	 */
	@Override
	public int getMnemonic() {
		return myMnemonic;
	}

	/**
	 * Returns the shape associated with the tool.
	 * 
	 * @return The shape.
	 */
	@Override
	public Shape getShape() {
		return null;
	}

	/**
	 * Sets the start point location.
	 * 
	 * @param thePoint The start point.
	 */
	@Override
	public void setStartPoint(Point thePoint) {
		myStartPoint = thePoint;

	}

	/**
	 * Returns the start point.
	 * 
	 * @return The start point.
	 */
	@Override
	public Point getStartPoint() {
		return myStartPoint;
	}

	/**
	 * Sets the next point for the shape. Will be handled by the individual tools.
	 */
	@Override
	public void setNextPoint(Point thePoint) {

	}

	/**
	 * Sets the start point back to the default point.
	 */
	@Override
	public void reset() {
		setStartPoint(DEFAULT_POINT);
	}

}
