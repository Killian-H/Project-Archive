/**
 * TCSS 305
 * 
 * Creates the Rectangle Tool object which provides specified behavior for this specific tool.
 */
package Model;

import java.awt.Point;
import java.awt.Shape;
import java.awt.event.KeyEvent;
import java.awt.geom.Rectangle2D;

/**
 * This class extends Abstract Paint Tool to give detailed information about
 * what shape the rectangle tool should return, as well as its name, and
 * mnemonic.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class RectangleTool extends AbstractPaintTool {

	/** The name of the tool. */
	private static final String MY_NAME = "Rectangle";

	/** The mnemonic associated with the tool. */
	private static final int MY_MNEMONIC = KeyEvent.VK_R;

	/** The next point after the start point. */
	private Point myNextPoint;

	/**
	 * A constructor which assigns the name and the mnemonic for the tool. It also
	 * provides a default starting point for the next point.
	 */
	public RectangleTool() {
		super(MY_NAME, MY_MNEMONIC);
		myNextPoint = DEFAULT_POINT;
	}

	/**
	 * Returns the shape for this tool. In this case it is a rectangle.
	 * 
	 * @return Returns a line.
	 */
	@Override
	public Shape getShape() {
		Rectangle2D rect = new Rectangle2D.Double();
		rect.setFrameFromDiagonal(getStartPoint(), myNextPoint);
		return rect;
	}

	/**
	 * Sets the start point for the rectangle. Assigns the next point to this point
	 * as well.
	 * 
	 * @param thePoint The point which the user clicks in the drawing panel.
	 */
	@Override
	public void setStartPoint(final Point thePoint) {
		super.setStartPoint(thePoint);
		myNextPoint = thePoint;
	}

	/**
	 * Sets the next point after the start point has been assigned.
	 * 
	 * @param thePoint The point which the user drags to.
	 */
	@Override
	public void setNextPoint(Point thePoint) {
		myNextPoint = thePoint;
	}

	/**
	 * Restores the start point to the default point, as well as the next point.
	 */
	@Override
	public void reset() {
		super.reset();
		myNextPoint = getStartPoint();
	}
}
