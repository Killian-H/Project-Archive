/*
 * TCSS 305
 * 
 * Creates the power paint menu bar.
 */
package View;

import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import java.util.Objects;

import javax.swing.ButtonGroup;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import Controller.ButtonAction;

/**
 * This class extends JMenuBar to create a menu bar designed for the power paint
 * program.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class PowerPaintMenuBar extends JMenuBar implements PropertyChangeListener {

	/** List of actions performed by clicking the tools. */
	private final List<ButtonAction> myButtonActions;

	/** The options menu. */
	private final JMenu myOptionsMenu;

	/** The tools menu. */
	private final JMenu myToolsMenu;

	/** The help menu. */
	private final JMenu myHelpMenu;

	/** The option to clear all shapes from the drawing panel. */
	private final JMenuItem myClearOption;

	/** The frame. */
	private final PowerPaintGUI myFrame;

	/** The drawing panel. */
	private final PowerPaintPanel myDrawingPanel;

	/** The icon for the "About" message dialog. */
	private final ImageIcon myIcon;

	/** The default primary color. */
	private final Color myDefaultPrim;

	/** The default secondary color. */
	private final Color myDefaultSec;

	/** Maximum thickness of the line. */
	private static final int MAX_THICKNESS = 20;

	/** The minimum thickness of the line. */
	private static final int MIN_THICKNESS = 0;

	/** The default thickness of the line. */
	private static final int DEFAULT_THICKNESS = 10;

	/** The major tick mark spacing for the slider. */
	private static final int MAJOR_THICKNESS = 5;

	/** The minor tick mark spacing for the slider. */
	private static final int MINOR_THICKNESS = 1;

	/**
	 * Constructs a new menu bar. Provides a reference to the power paint frame,
	 * panel, and the tools needed for the tools menu.
	 * 
	 * @param theFrame         The power paint frame.
	 * @param theDrawingPanel  The power paint panel.
	 * @param theButtonActions List of tools with actions associated with them.
	 */
	public PowerPaintMenuBar(final PowerPaintGUI theFrame, final PowerPaintPanel theDrawingPanel,
			List<ButtonAction> theButtonActions) {
		myFrame = Objects.requireNonNull(theFrame);
		myDrawingPanel = Objects.requireNonNull(theDrawingPanel);
		myDrawingPanel.addPropertyChangeListener(this);
		myButtonActions = Objects.requireNonNull(theButtonActions);
		myOptionsMenu = new JMenu();
		myToolsMenu = new JMenu();
		myHelpMenu = new JMenu();
		myClearOption = new JMenuItem("Clear");
		myIcon = new ImageIcon("w.gif");
		myDefaultPrim = new Color(51, 0, 111);
		myDefaultSec = new Color(232, 211, 162);
		constructMenuBar();
	}

	/**
	 * Adds each menu to the menu bar.
	 */
	private void constructMenuBar() {
		add(optionsMenu());
		add(toolsMenu());
		add(helpMenu());
	}

	/**
	 * Sets the name of the Options menu. It also adds the menu items to this menu.
	 * These items are the controller for the line width, the primary color, the
	 * secondary color, and the clear command.
	 * 
	 * @return The fully constructed Options menu.
	 */
	private JMenu optionsMenu() {
		myOptionsMenu.setText("Options");
		myOptionsMenu.setMnemonic(KeyEvent.VK_O);
		myOptionsMenu.add(thicknessItem());
		myOptionsMenu.addSeparator();
		myOptionsMenu.add(primaryColor());
		myOptionsMenu.add(secondaryColor());
		myOptionsMenu.addSeparator();
		myOptionsMenu.add(constructClear());
		return myOptionsMenu;
	}

	/**
	 * Constructs the menu item to control the thickness of the line. Adds the
	 * slider to the thickness item to allow control of the line width.
	 * 
	 * @return The Thickness menu item.
	 */
	private JMenu thicknessItem() {
		final JMenu thickness = new JMenu("Thickness");
		thickness.setMnemonic(KeyEvent.VK_T);
		thickness.add(thickSlider());
		return thickness;
	}

	/**
	 * Creates the Thickness Slider to control the thickness of the line. Sets the
	 * minimum and maximum value, as well as the tick spacing for the slider. A
	 * change listener is attached to the slider to listen for when the value
	 * changes.
	 * 
	 * @return The Thickness Slider.
	 */
	private JSlider thickSlider() {
		final JSlider controlThickness = new JSlider(JSlider.HORIZONTAL, MIN_THICKNESS, MAX_THICKNESS, DEFAULT_THICKNESS);
		controlThickness.setMajorTickSpacing(MAJOR_THICKNESS);
		controlThickness.setMinorTickSpacing(MINOR_THICKNESS);
		controlThickness.setPaintLabels(true);
		controlThickness.setPaintTicks(true);
		controlThickness.setSnapToTicks(true);
		controlThickness.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				int value = controlThickness.getValue();
				if (value >= 0) {
					myDrawingPanel.setLineWidth(value);
				}
			}
		});
		return controlThickness;
	}

	/**
	 * Creates the Primary Color menu item. When clicked a color chooser dialog will
	 * appear. The user can select a new primary color from this color chooser. The
	 * change will be reflected in the icon for this menu item.
	 * 
	 * @return The Primary Color menu item.
	 */
	private JMenuItem primaryColor() {
		JMenuItem primColor = new JMenuItem("Primary Color...");
		primColor.setMnemonic(KeyEvent.VK_P);
		final ColorIcon primIcon = new ColorIcon(myDefaultPrim);
		primColor.setIcon(primIcon);
		primColor.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Color newColor = JColorChooser.showDialog(myFrame, "Choose A Color", myDefaultSec);
				if (newColor != null) {
					primIcon.setColor(newColor);
					myDrawingPanel.setPrimColor(newColor);
				}
			}

		});
		return primColor;
	}

	/**
	 * Creates the Secondary Color menu item. When clicked a color chooser dialog
	 * will appear. The user can select a new secondary color from this color
	 * chooser. The change will be reflected in the icon for this menu item.
	 * 
	 * @return The Secondary Color menu item.
	 */
	private JMenuItem secondaryColor() {
		JMenuItem secColor = new JMenuItem("Secondary Color...");
		secColor.setMnemonic(KeyEvent.VK_S);
		final ColorIcon secIcon = new ColorIcon(myDefaultSec);
		secColor.setIcon(secIcon);
		secColor.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Color newColor = JColorChooser.showDialog(myFrame, "Choose A Color", myDefaultSec);
				if (newColor != null) {
					secIcon.setColor(newColor);
					myDrawingPanel.setSecColor(newColor);
				}
			}

		});
		return secColor;
	}

	/**
	 * Creates the Clear menu item. When selected it will empty the list of drawn
	 * shapes and call repaint(). This will clear all shapes from the panel. If
	 * there are no shapes on the panel, the user will be unable to select this
	 * option.
	 * 
	 * @return The Clear menu item.
	 */
	private JMenuItem constructClear() {
		myClearOption.setMnemonic(KeyEvent.VK_C);
		myClearOption.setEnabled(false);
		myClearOption.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				myDrawingPanel.clearPanel();
			}
		});
		return myClearOption;
	}

	/**
	 * Creates the Tools menu, and the menu items for the tool menu. Adds all of the
	 * menu items to a button group, so that only one tool can be selected at a
	 * time.
	 * 
	 * @return The Tools menu with the menu items.
	 */
	private JMenu toolsMenu() {
		myToolsMenu.setText("Tools");
		myToolsMenu.setMnemonic(KeyEvent.VK_T);
		final ButtonGroup toolBtnGrp = new ButtonGroup();
		for (final ButtonAction ba : myButtonActions) {
			final JRadioButtonMenuItem btn = new JRadioButtonMenuItem(ba);
			toolBtnGrp.add(btn);
			myToolsMenu.add(btn);
		}
		return myToolsMenu;
	}

	/**
	 * Creates the Help menu and adds the about menu item to it.
	 * 
	 * @return The Help menu.
	 */
	private JMenu helpMenu() {
		myHelpMenu.setText("Help");
		myHelpMenu.setMnemonic(KeyEvent.VK_H);
		myHelpMenu.add(aboutSubMenu());
		return myHelpMenu;
	}

	/**
	 * Constructs the About menu item. When selected a message dialog will appear
	 * with information about the creator of this program.
	 * 
	 * @return The About menu item.
	 */
	private JMenuItem aboutSubMenu() {
		final Image icon = myIcon.getImage().getScaledInstance(50, 35, Image.SCALE_SMOOTH);
		final ImageIcon scaledIcon = new ImageIcon(icon);
		final JMenuItem about = new JMenuItem("About");
		about.setMnemonic(KeyEvent.VK_A);
		about.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(myFrame, "Killian Hickey\n Autumn 2020\n TCSS 305 Assignment 4", "About",
						JOptionPane.INFORMATION_MESSAGE, scaledIcon);
			}

		});
		return about;
	}

	/**
	 * Listens for property changes and sets the clear option accordingly. 
	 * 
	 * @param theEvent The property change.
	 */
	@Override
	public void propertyChange(PropertyChangeEvent theEvent) {
		if ("No items in list".equals(theEvent.getPropertyName())) {
			myClearOption.setEnabled((boolean) theEvent.getNewValue());
		} else if ("Items in list".equals(theEvent.getPropertyName())) {
			myClearOption.setEnabled((boolean) theEvent.getNewValue());
		}

	}
}
