/*
 * TCSS 305
 * 
 * Creates the power paint panel object, which will hold the toolbar, and be drawn on by the user.
 */
package View;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.ArrayList;
import java.util.Objects;

import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.event.MouseInputAdapter;

import Model.EraserTool;
import Model.LineTool;
import Model.PaintTool;
import Model.RedrawShape;

/**
 * This class handles the creation of the panel which will be drawn on.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class PowerPaintPanel extends JPanel {

	/** The size of the drawing panel. */
	private static final Dimension PANEL_SIZE = new Dimension(500, 300);

	/** The default background color of the panel. */
	private static final Color BACKGROUND_COLOR = Color.WHITE;

	/** The default primary color. */
	private static final Color DEFAULT_PRIM = new Color(51, 0, 111);

	/** The default secondary color. */
	private static final Color DEFAULT_SEC = new Color(232, 211, 162);

	/** The default width of the line. */
	private static final int DEFAULT_WIDTH = 10;

	/** The primary color. */
	private Color myPrimLineColor;

	/** The secondary color. */
	private Color mySecLineColor;

	/** The current color being used. */
	private Color myCurrentColor;

	/** The line width. */
	private int myLineWidth;

	/** List of shapes previously drawn. */
	private ArrayList<RedrawShape> myShapes;

	/** The current tool being used. */
	private PaintTool myCurrentTool;

	/** Support for listening to property changes. */
	private final PropertyChangeSupport myPropertyListener;

	/**
	 * Constructor which creates the panel to be used. It also assigns the default
	 * values needed for the colors being used, and the tool that is initially
	 * selected.
	 */
	public PowerPaintPanel() {
		setPreferredSize(PANEL_SIZE);
		setBackground(BACKGROUND_COLOR);
		setLayout(new BorderLayout());
		myLineWidth = DEFAULT_WIDTH;
		myPrimLineColor = DEFAULT_PRIM;
		mySecLineColor = DEFAULT_SEC;
		myCurrentColor = DEFAULT_SEC;
		myCurrentTool = new LineTool();
		myShapes = new ArrayList<RedrawShape>();
		myPropertyListener = new PropertyChangeSupport(this);
		createPanel();
	}

	/**
	 * Sets the cursor to be a crosshair when hovering over the panel. Also adds a
	 * mouse adapter to the panel.
	 */
	private void createPanel() {
		setCursor(Cursor.getPredefinedCursor(Cursor.CROSSHAIR_CURSOR));
		final MouseInputAdapter mia = new MyMouseHandler();
		addMouseListener(mia);
		addMouseMotionListener(mia);
	}

	/**
	 * Overrides the default implementation of the paint component to set it up for
	 * the purposes of this program. Has a reference to the tool being used, as well
	 * as what shape is associated with said tool. Will draw the current shape the
	 * user is drawing, as well as all previous shapes the user has drawn.
	 * 
	 * @param theGraphics A graphics object.
	 */
	@Override
	public void paintComponent(final Graphics theGraphics) {
		Shape currentShape = myCurrentTool.getShape();
		super.paintComponent(theGraphics);
		final Graphics2D g2d = (Graphics2D) theGraphics;
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		for (RedrawShape rs : myShapes) {
			if (Objects.nonNull(rs.getShape())) {
				g2d.setPaint(rs.getColor());
				g2d.setStroke(new BasicStroke(rs.getWidth()));
				g2d.draw(rs.getShape());

			}
		}
		g2d.setPaint(myCurrentColor);
		g2d.setStroke(new BasicStroke(myLineWidth));
		g2d.draw(currentShape);
	}

	/**
	 * Adds a property change listener to the component.
	 * 
	 * @param theListener The listener being added.
	 */
	public void addPropertyChangeListener(PropertyChangeListener theListener) {
		this.myPropertyListener.addPropertyChangeListener(theListener);
	}

	/**
	 * Removes a property change listener from the component.
	 * 
	 * @param theListener The listener being added.
	 */
	public void removePropertyChangeListener(PropertyChangeListener theListener) {
		this.myPropertyListener.removePropertyChangeListener(theListener);
	}

	/**
	 * Clears out the array list when the user selects the clear option from the
	 * options menu, erasing all shapes on the panel. Fires a property change
	 * telling the menu there is no longer anything in the list.
	 */
	protected void clearPanel() {
		myShapes.clear();
		repaint();
		myPropertyListener.firePropertyChange("No items in list", true, false);
	}

	/**
	 * Sets which color will be used based on which button the user clicks on the
	 * mouse. If it is the left mouse button the primary color will be used. If it
	 * is the right mouse button the secondary color will be used.
	 * 
	 * @param theEvent The clicking of the mouse.
	 */
	protected void setColor(MouseEvent theEvent) {
		if (SwingUtilities.isLeftMouseButton(theEvent)) {
			setUsedColor(myPrimLineColor);
		}
		if (SwingUtilities.isRightMouseButton(theEvent)) {
			setUsedColor(mySecLineColor);
		}
	}

	/**
	 * Sets the primary color.
	 * 
	 * @param thePrimColor The color to be set to.
	 */
	protected void setPrimColor(Color thePrimColor) {
		myPrimLineColor = Objects.requireNonNull(thePrimColor);
	}

	/**
	 * Sets the secondary color.
	 * 
	 * @param theSecColor The color to be set to.
	 */
	protected void setSecColor(Color theSecColor) {
		mySecLineColor = Objects.requireNonNull(theSecColor);
	}

	/**
	 * Sets the current color to be used. It is based on which mouse button is
	 * pressed.
	 * 
	 * @param theCurrentColor The color to draw with.
	 */
	private void setUsedColor(Color theCurrentColor) {
		myCurrentColor = Objects.requireNonNull(theCurrentColor);
	}

	/**
	 * Sets the width of the shape.
	 * 
	 * @param theWidth The width to be set to.
	 */
	protected void setLineWidth(int theWidth) {
		if (theWidth < 0) {
			throw new IllegalArgumentException("Width of the line must at least be 0.");
		}
		myLineWidth = theWidth;
	}

	/**
	 * Sets the current tool being used.
	 * 
	 * @param theTool The tool being used.
	 */
	public void setTool(PaintTool theTool) {
		myCurrentTool = Objects.requireNonNull(theTool);
	}

	/**
	 * This class handles the mouse inputs from the user.
	 * 
	 * @author Killian Hickey
	 * @version December 10, 2020
	 *
	 */
	private class MyMouseHandler extends MouseInputAdapter {

		/**
		 * When the user presses the mouse button the start point is set. If the current
		 * tool being used is the eraser the color will be set to the color of the
		 * background.
		 * 
		 * @param theEvent The press of a button on the mouse.
		 */
		@Override
		public void mousePressed(MouseEvent theEvent) {
			if (myLineWidth > 0) {
				setColor(theEvent);
				if (myCurrentTool instanceof EraserTool) {
					setUsedColor(BACKGROUND_COLOR);
				}
				myCurrentTool.setStartPoint(theEvent.getPoint());
				repaint();
			}
		}

		/**
		 * As the mouse is dragged this will set the next point to the current position
		 * of the mouse pointer.
		 * 
		 * @param theEvent The dragging of the mouse.
		 */
		@Override
		public void mouseDragged(MouseEvent theEvent) {
			if (myLineWidth > 0) {
				myCurrentTool.setNextPoint(theEvent.getPoint());
				repaint();
			}
		}

		/**
		 * Once the mouse is released the shape drawn will be added to an array list so
		 * it may be redrawn each time repaint is called. The coordinates will be reset
		 * to their defaults after the mouse button is released. A property change will
		 * be fired, telling the menu there is something in the list.
		 */
		@Override
		public void mouseReleased(MouseEvent theEvent) {
			if (myLineWidth > 0) {
				myCurrentTool.setNextPoint(theEvent.getPoint());
				myShapes.add(new RedrawShape(myCurrentTool.getShape(), myCurrentColor, myLineWidth));
				myCurrentTool.reset();
				myPropertyListener.firePropertyChange("Items in list", false, true);
				repaint();
			}
		}
	}
}
