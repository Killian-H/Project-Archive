/*
 * TCSS 305
 *
 * Creates the power paint toolbar which holds the tools that can be used to draw with.
 */
package View;

import java.util.List;
import java.util.Objects;

import javax.swing.ButtonGroup;
import javax.swing.JToggleButton;
import javax.swing.JToolBar;

import Controller.ButtonAction;

/**
 * This class assigns a button group to the tools the user can use so that only
 * one can be selected at a time. It then adds the buttons to a toolbar.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class PowerPaintToolBar extends JToolBar {

	/** List of available tools. */
	private final List<ButtonAction> myButtonActions;

	/**
	 * Constructor which initializes the list of tools and calls the method to set
	 * up the toolbar.
	 * 
	 * @param theButtonActions List of tools and action associated with each tool.
	 */
	public PowerPaintToolBar(List<ButtonAction> theButtonActions) {
		myButtonActions = Objects.requireNonNull(theButtonActions);
		createToolBar();
	}

	/**
	 * Iterates through the list of tools, adds them to a button group, and then
	 * adds them to the toolbar
	 */
	private void createToolBar() {
		final ButtonGroup btngrp = new ButtonGroup();
		for (final ButtonAction ba : myButtonActions) {
			final JToggleButton toolButton = new JToggleButton(ba);
			btngrp.add(toolButton);
			add(toolButton);
		}
	}
}
