/*
 * TCSS 305
 * 
 * This class creates the color icon object to be used in the power paint menu.
 */
package View;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.Objects;

import javax.swing.Icon;

/**
 * This class creates an icon to display in the menu for the power paint frame.
 * The icon is updated based on what color the user decides to use.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class ColorIcon implements Icon {

	/** The color of the icon. */
	private Color myColor;

	/** The size of the icon. */
	private static final int MY_SIZE = 5;

	/** The x-coordinate of the icon in the menu. */
	private static final int MY_X = 10;

	/** The y-coordinate of the icon in the menu. */
	private static final int MY_Y = 5;

	/** The width of the icon. */
	private static final int MY_WIDTH = 35;

	/** The height of the icon. */
	private static final int MY_HEIGHT = 35;

	/**
	 * A constructor which sets the color of the icon.
	 * 
	 * @param theColor The color to be set to.
	 */
	public ColorIcon(Color theColor) {
		myColor = Objects.requireNonNull(theColor);
	}

	/**
	 * Sets the color of the icon to the selected color.
	 * 
	 * @param theColor The color to be set to.
	 */
	public void setColor(Color theColor) {
		myColor = Objects.requireNonNull(theColor);
	}

	/**
	 * Overrides the default behavior for paint icon to allow it to work in the
	 * context of the power paint panel. Sets the color of the icon, as well as the
	 * shape and size of it.
	 * 
	 */
	@Override
	public void paintIcon(Component c, Graphics theGraphics, int theX, int theY) {
		final Graphics icon2D = (Graphics2D) Objects.requireNonNull(theGraphics);
		if (theX < 0) {
			throw new IllegalArgumentException("The icon's x-coordinate cannot be negative.");
		}
		if  (theY < 0) {
			throw new IllegalArgumentException("The icon's y-coordinate cannot be negative.");
		}
		icon2D.setColor(myColor);
		icon2D.fillRect(theX - MY_X, theY - MY_Y, MY_WIDTH + MY_SIZE, MY_HEIGHT + MY_SIZE);
	}

	/**
	 * The width of the icon.
	 */
	@Override
	public int getIconWidth() {
		return MY_WIDTH;
	}

	/**
	 * The height of the icon.
	 */
	@Override
	public int getIconHeight() {
		return MY_HEIGHT;
	}
}
