/*
 * TCSS 305
 * 
 * Sets up the Power Paint GUI the user will be interacting with.
 */
package View;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import Controller.ButtonAction;
import Model.EllipseTool;
import Model.EraserTool;
import Model.LineTool;
import Model.PencilTool;
import Model.RectangleTool;

/**
 * This class creates the frame that all other components will be built on.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class PowerPaintGUI extends JFrame {

	/** The title of the program. */
	private static final String MY_TITLE = "Power Paint";

	/** Tool used to get the size of the user's screen. */
	private final Dimension myScreenSize = Toolkit.getDefaultToolkit().getScreenSize();

	/** Name of the icon for the program. */
	private static final String FILE_IMAGE = "w.gif";

	/** The panel to be added to the frame. */
	private PowerPaintPanel myDrawingPanel;

	/** A list of the available tools. */
	private List<ButtonAction> myButtonActions;

	/**
	 * Sets the title of the program, and initializes the panel to be used, as well
	 * as the list of tools. Each tool is then added to the list, along with an icon
	 * assigned to the tool.
	 */
	public PowerPaintGUI() {
		super(MY_TITLE);
		myDrawingPanel = new PowerPaintPanel();
		myButtonActions = new ArrayList<ButtonAction>();
		myButtonActions.add(new ButtonAction("Line", new LineTool(), new ImageIcon("line_bw.gif"), myDrawingPanel));
		myButtonActions
				.add(new ButtonAction("Pencil", new PencilTool(), new ImageIcon("pencil_bw.gif"), myDrawingPanel));
		myButtonActions.add(
				new ButtonAction("Rectangle", new RectangleTool(), new ImageIcon("rectangle_bw.gif"), myDrawingPanel));
		myButtonActions
				.add(new ButtonAction("Ellipse", new EllipseTool(), new ImageIcon("ellipse_bw.gif"), myDrawingPanel));
		myButtonActions
				.add(new ButtonAction("Eraser", new EraserTool(), new ImageIcon("eraser_bw.gif"), myDrawingPanel));
		createAndSetFrame();
	}

	/**
	 * Sets the icon for the frame, and attaches the power paint menu and the
	 * drawing panel. Also adds the power paint tool bar to the drawing panel. Sets
	 * the location at which the frame appears to be the center of the user's
	 * screen.
	 */
	public void createAndSetFrame() {
		final ImageIcon icon = new ImageIcon(FILE_IMAGE);
		setIconImage(icon.getImage());
		final PowerPaintMenuBar menu = new PowerPaintMenuBar(this, myDrawingPanel, myButtonActions);
		setJMenuBar(menu);
		add(myDrawingPanel, BorderLayout.CENTER);
		final PowerPaintToolBar paintButton = new PowerPaintToolBar(myButtonActions);
		myDrawingPanel.add(paintButton, BorderLayout.SOUTH);
		pack();
		setLocation((int) myScreenSize.getWidth() / 2 - this.getWidth() / 2,
				(int) myScreenSize.getHeight() / 2 - this.getHeight() / 2);
	}
}
