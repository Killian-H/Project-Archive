/*
 * TCSS 305
 * 
 * Starts the Power Paint program.
 */
package Controller;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.UIManager;

import View.PowerPaintGUI;

/**
 * This class starts the power paint program, assigns a theme to the frame, and sets the default
 * close behavior.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class PowerPaintMain {

	/**
	 * Starts the power paint program.
	 */
	public static void main(String[] args) {
		try {
			UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
		} catch (Exception ex) {

		}
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {

				final PowerPaintGUI start = new PowerPaintGUI();
				start.setVisible(true);
				start.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			}
		});
	}
}
