/**
 * TCSS 305
 * 
 * Creates the default logic behind the buttons being used to switch the tools.
 */

package Controller;

import java.awt.Image;
import java.awt.event.ActionEvent;
import java.util.Objects;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.ImageIcon;

import Model.PaintTool;
import View.PowerPaintPanel;

/**
 * This class sets up the logic behind each of the buttons for the tools. It
 * assigns the mnemonic to the button, as well as the icon and the tool.
 * 
 * @author Killian Hickey
 * @version December 10, 2020
 *
 */
public class ButtonAction extends AbstractAction {

    /** The power paint tool. */
    private final PaintTool myTool;

    /** The icon associated with the tool. */
    private final ImageIcon myIcon;

    /** The drawing panel. */
    private final PowerPaintPanel myDrawingPanel;

    /**
     * Constructor which assigns the name of the tool, the tool itself, the icon
     * associated with the tool, and the panel which the buttons will be attached to
     * to the button itself.
     * 
     * @param theName         The name of the tool.
     * @param theTool         The drawing tool.
     * @param theIcon         The icon associated with the tool.
     * @param theDrawingPanel A reference to the panel being drawn on.
     */
    public ButtonAction(String theName, PaintTool theTool, 
    		Icon theIcon, PowerPaintPanel theDrawingPanel) {
        super(Objects.requireNonNull(theName));
        myDrawingPanel = Objects.requireNonNull(theDrawingPanel);
        myTool = Objects.requireNonNull(theTool);
        putValue(MNEMONIC_KEY, myTool.getMnemonic());
        putValue(SELECTED_KEY, true);
        myIcon = (ImageIcon) Objects.requireNonNull(theIcon);
        setUpImage();
    }

    /**
     * Sets what action happens when the tool is selected. In this case it changes
     * which tool is selected.
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        myDrawingPanel.setTool(myTool);

    }

    /**
     * Sets the dimensions of the icon associated with the tool.
     */
    public void setUpImage() {
        final Image largeImage = myIcon.getImage().getScaledInstance(15, -1, java.awt.Image.SCALE_SMOOTH);
        final ImageIcon largeIcon = new ImageIcon(largeImage);
        putValue(Action.LARGE_ICON_KEY, largeIcon);
    }

}
