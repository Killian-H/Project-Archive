/**
 * TCSS 342
 * Interface to extend the queue interface with a new method.
 */
package structures;

/**
 * An interface used to extend another interface.
 *
 * @author Killian Hickey
 * @version 01/24/21
 *
 * @param <E> Generic Argument.
 */
public interface OutputRestrictedDequeADT<E> extends QueueADT<E> {

    /**
     * Allows for enqueuing at the front of a queue.
     *
     * @param theElement The Object being enqueued.
     */
    void enqueueAtFront(E theElement);
}
