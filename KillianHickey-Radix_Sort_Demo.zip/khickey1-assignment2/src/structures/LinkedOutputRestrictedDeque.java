/*
 * TCSS 342
 *
 * This class extends the LinkedQueue class to provide new functionality.
 */
package structures;

/**
 * This class provides the ability to enqueue new nodes at the front of a queue.
 *
 * @author Killian Hickey
 * @version 01/20/2021
 *
 * @param <E>
 */
public class LinkedOutputRestrictedDeque<E> extends LinkedQueue
        implements
            OutputRestrictedDequeADT {

    /**
     * This method gives the ability to enqueue nodes at the front of a queue.
     * If there are no Nodes in the queue it will call Enqueue from the linked
     * queue class. Suppresses the warnings because there is no way to fix them.
     */
    @SuppressWarnings("unchecked")
    @Override
    public void enqueueAtFront(final Object theElement) {
        if (mySize == 0) {
            enqueue(theElement);
        } else {
            Node<E> temp = myFront;
            myFront = new Node<>((E) theElement);
            myFront.setMyNext(temp);
            mySize++;
        }
    }

}
