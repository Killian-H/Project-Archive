/*
 * TCSS 342
 *
 * Test class for the OutputRestrictedQueueADT and the class it
 * extends LinkedQueue.
 */

package tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import exceptions.EmptyCollectionException;
import structures.LinkedQueue;
import structures.LinkedOutputRestrictedDeque;

/**
 * This class tests the methods provided by LinkedQueue and its child class.
 *
 * @author Killian Hickey
 * @version 01/20/2021
 *
 */
public class LinkedOutputRestrictedDequeTest {

    /**
     * Linked queue which will be filled with nodes.
     */
    private LinkedQueue<String> testQueue = new LinkedQueue<>();

    /**
     * Linked queue which will test what happens when a queue is empty.
     */
    private LinkedQueue<String> testEmpty = new LinkedQueue<>();

    /**
     * Linked queue to test the enqueue at front method.
     */
    private LinkedOutputRestrictedDeque<String> testEnqFront =
            new LinkedOutputRestrictedDeque<>();

    /**
     * Empty linked queue to test what happens when enqueueAtFront is called on
     * an empty queue.
     */
    private LinkedOutputRestrictedDeque<String> testEnqFntEmp =
            new LinkedOutputRestrictedDeque<>();

    /**
     * Adds nodes to the queues.
     *
     * @throws Exception
     */
    @Before
    public void setUp() throws Exception {
        testQueue.enqueue("a");
        testQueue.enqueue("b");
        testEnqFront.enqueue("a");
        testEnqFront.enqueue("b");
        testEnqFront.enqueue("c");
    }

    /**
     * Test for enqueuing a string to the queue.
     */
    @Test
    public void testEnqueue() {
        testQueue.enqueue("c");
        assertEquals("Failed to enqueue the string!", "front -> a, b, c",
                testQueue.toString());
    }

    /**
     * Test for enqueuing to an empty queue.
     */
    @Test
    public void testEnqueueEmpty() {
        testEmpty.enqueue("pass");
        assertEquals("Failed to enqueue in an empty queue!", "front -> pass",
                testEmpty.toString());
    }

    /**
     * Test for dequeuing the elements from a queue.
     */
    @Test
    public void testDequeue() {
        testQueue.dequeue();
        assertEquals("Failed to dequeue a!", "front -> b",
                testQueue.toString());
        testQueue.dequeue();
        assertEquals("Failed to return an empty string!", "",
                testQueue.toString());
    }

    /**
     * Test for an invalid call on dequeue.
     */
    @Test(expected = EmptyCollectionException.class)
    public void testDequeueEmpty() {
        testEmpty.dequeue();
    }

    /**
     * Test to see if first will return the correct data of the node.
     */
    @Test
    public void testFirst() {
        assertEquals("Failed to return the first object in the queue!", "a",
                testQueue.first());
    }

    /**
     * Test for calling first on an empty queue.
     */
    @Test(expected = EmptyCollectionException.class)
    public void testFirstEmpty() {
        testEmpty.first();
    }

    /**
     * Testing if the size method returns the correct number of nodes in the
     * queue.
     */
    @Test
    public void testSize() {
        assertEquals("Size was not two!", 2, testQueue.size());
        assertEquals("Size was not zero!", 0, testEmpty.size());
    }

    /**
     * Test to see if calling isEmpty() returns the correct boolean value.
     */
    @Test
    public void testIsEmpty() {
        assertFalse("Failed to return false for a populated queue!",
                testQueue.isEmpty());
        assertTrue("Failed to return true for an empty queue!",
                testEmpty.isEmpty());
    }

    /**
     * Test to determine whether enqueuing at the front of a queue is working
     * correctly.
     */
    @Test
    public void testEnqueueAtFront() {
        testEnqFront.enqueueAtFront("d");
        testEnqFront.enqueueAtFront("bad");
        assertEquals("Failed to enqueue at the front of the queue!",
                "front -> bad, d, a, b, c", testEnqFront.toString());
    }

    /**
     * Test to see if calling enqueueAtFront() on an empty queue will produce
     * the correct order.
     */
    @Test
    public void testEnqueueAtFrontEmpty() {
        testEnqFntEmp.enqueueAtFront("a");
        assertEquals("Failed to enqueue properly!", "front -> a",
                testEnqFntEmp.toString());
    }

    /**
     * Test to see if the front pointer is pointing to the correct node after
     * enqueuing at the front of a queue.
     */
    @Test
    public void testFirstAfterEnqueueFront() {
        testEnqFront.enqueueAtFront("test");
        assertEquals("Failed to return the correct string!", "test",
                testEnqFront.first());
    }
}
