/*
 * TCSS 342
 *
 *  Program which reads a file of integers and sorts using a radix sort method.
 */

package applications;

import java.io.File;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import structures.LinkedOutputRestrictedDeque;
import structures.LinkedQueue;

/**
 * This class is designed to implement a radix sort method. It sorts positive
 * integers read from a file. It sorts the integers from smallest to largest
 * then writes the sorted list of integers to an output file.
 * WARNING: Original sort of the queue will be lost upon using this method.
 *
 * @author Killian Hickey
 * @version 01/20/2021
 *
 */

public final class RadixSortDemo {

    /** Number used for division and modulus throughout program. */
    private static final int DIV_TEN = 10;

    /** The size of the array holding the queues. */
    private static final int ARRAY_SIZE = 10;

    /**
     * Private constructor created so a new RadixSortDemo cannot be
     * instantiated.
     */
    private RadixSortDemo() {
        // Do nothing
    }

    /**
     * The main driver of the program. It handles checking for whether the
     * file entered by the user exists, as well as making method calls.
     *
     * @param theArgs
     */
    public static void main(final String[] theArgs) {
        printIntroduction();
        final Scanner console = new Scanner(System.in);
        final String file = getName(console);
        File tmp = new File(file);
        while (!tmp.canRead()) {
            tmp = new File(checkFileName(console));
        }
        try {
            final Scanner readFile = new Scanner(tmp);
           final LinkedQueue<Integer> intFromFile =
                   new LinkedOutputRestrictedDeque<Integer>();
            while (readFile.hasNextInt()) {
                intFromFile.enqueue(readFile.nextInt());
            }
            readFile.close();
            LinkedQueue<Integer> sortedQueue = radixSort(intFromFile);
            printToFile(sortedQueue);
        } catch (Exception e) {
            System.out.println("exception?");
        }
    }

    /**
     * This method prints an introduction explaining what the program will do.
     */
    private static void printIntroduction() {
        final String intro = "This program will prompt the user for the name "
                + "of a file which will contain x amount of positive integers."
                + "\nThese integers will then "
                + "be sorted using a radix sort method. "
                + "Please give it a try!\n\n";
        System.out.println(intro);
    }

    /**
     * This method prompts the user to enter the name of the file they would
     * like to have read.
     *
     * @param theConsole Scanner listening for user input.
     * @return Returns the name of the file the user has entered.
     */
    private static String getName(final Scanner theConsole) {
        System.out
                .print("Please input the name of the file you want to read: ");
        final String s = theConsole.next();
        return s;
    }

    /**
     * If the file the user entered previously cannot be found, the user will be
     * re-prompted to enter the correct name of the file.
     *
     * @param theConsole Scanner listening for user input.
     * @return Returns the corrected input file name from the user.
     */
    private static String checkFileName(final Scanner theConsole) {
        System.out.print(
                "I'm sorry, that file could not be found. Please try again: ");
        String s = theConsole.next();
        return s;
    }
    /**
     * This method sorts a given file using the radix sort method. It does
     * this by first reading the integer passed in, then checking each
     * individual number in that integer. It then repeatedly enqueues and
     * dequeues until the queue is sorted.
     *
     * @param theIntQueue The queue containing integers from a file.
     * @return Returns the sorted queue.
     */
    public static LinkedQueue<Integer> radixSort(
            final LinkedQueue theIntQueue) {
        int maxNumDigits = getMax(theIntQueue);
        List<LinkedOutputRestrictedDeque<Integer>> digitQueues =
                new ArrayList<>();
        addQueues(digitQueues);
        int fullQueueSize = theIntQueue.size();
        for (int i = 1; i <= maxNumDigits; i++) {
            for (int j = 0; j < fullQueueSize; j++) {
                int current = (int) theIntQueue.dequeue();
                int index = getDigit(current, i);
                digitQueues.get(index).enqueue(current);
            }
            for (int k = 0; k < digitQueues.size(); k++) {
                while (!digitQueues.get(k).isEmpty()) {
                    theIntQueue.enqueue(digitQueues.get(k).dequeue());
                }
            }
        }
        System.out.println(theIntQueue.toString());
        return theIntQueue;
    }

    /**
     * Determines what the highest integer length is within the given file.
     *
     * @param theIntQueue The queue containing integers from a file.
     * @return The largest integer length from file.
     */
    private static int getMax(final LinkedQueue<Integer> theIntQueue) {
        int max = 0;
        int queueSize = theIntQueue.size();
        while (queueSize > 0) {
            final int current = (int) theIntQueue.dequeue();
            if (current > max) {
                max = current;
            }
            while (max / DIV_TEN > 0) {
                max = max / DIV_TEN;
            }
            queueSize--;
            theIntQueue.enqueue(current);
        }
        return max;
    }

    private static int getDigit(final int theNum, final int theDigit) {
        int current = theNum;
        for (int i = 0; i < theDigit - 1; i++) {
            current = current / DIV_TEN;
        }
        return current % DIV_TEN;
    }

    /**
     * This is a helper method for radixSort(). It adds ten queues to an
     * array list in order to store the integers from the file.
     *
     * @param theArray The array holding the queues.
     */
    private static void addQueues(
            final List<LinkedOutputRestrictedDeque<Integer>> theArray) {
     for (int i = 0; i < ARRAY_SIZE; i++) {
         theArray.add(new LinkedOutputRestrictedDeque<Integer>());
     }
    }

    /**
     * This methods prints the sorted queue to a file named "output.txt".
     *
     * @param theQueue
     *            The sorted queue of integers.
     */
    private static void printToFile(final LinkedQueue<Integer> theQueue) {
        try {
            final FileOutputStream file = new FileOutputStream("output.txt");
            PrintWriter dos = new PrintWriter(file);
            while (!theQueue.isEmpty()) {
                dos.write(theQueue.dequeue().toString());
                dos.write("\n");
            }
            dos.close();
        } catch (Exception e) {

        }

    }
}
